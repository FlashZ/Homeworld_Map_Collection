Map : Conflict of Interest
Players : 2
Settings : Unit Capping Off, Crates Off, Small Bounties, Large Starting Resources

-----

Installing

	Simply unzip the "Conflict2" folder to your "HomeWorld/Multiplayer/" directory and it will appear in all mulitplayer modes.

-----

Notes from the author

	This was my first map. The sparks start flying as collection groups clash at the outer edges of the ring. The late game fight centers around 2 regenerating dust clouds.

-----

About my maps

	All my maps are 2 player only. Sorry, but I can't reload a map into the mission editor [it locks up], so I have to create a map all at once an then tweak it in notepad.  If I can get this fixed I'll start creating maps for 2-? players, but until then you'll have to bear with me. Hey...at least you don't have to worry about anyone joining your 1v1 at the last second!

-----

Please send feedback [good or bad] or suggestions to brethenc@hotmail.com