Hey, here it is finished, Donuts v2.01

This is my first proper map which was inspired by a great hero of mine Mr HOMER SIMPSON.

Like to thank (in no particular order)

Dylov for his map making primer
Taker for the ring generator
FoX for his kick-ass background. Will be using more of yours dude because this one rocks.
The inhabitants of Relic Editing and others who were wiling victims of it.

This map is kinda an attempt to ween the ladder community off Subjugate, it'll work if 
enough peeps play on it. It's small but not as centralised, hope you like.

Stoned out.

