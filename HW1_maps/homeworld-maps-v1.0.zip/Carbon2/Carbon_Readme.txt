Homeworld Custom Map

====================
Creator: Dylov
E-Mail Address:  dy.lov@techemail.com

Map Name:  Carbon-14
File Name:  Carbon.zip
Version:  1.0 (31 August 2000)
Created With:  Excel97, TextPad v.4.3.1:32-Bit Edition, Silk-Cut and Nescaf� 
====================

Background Storyline and/or Comments:

Original concept and design of the Cosmic Carbon-14 Molecule Map by Aged-OMO.
Background by Medamanx (www.strategyplanet.com/hwmaps)

*************

This map has been designed for a Two Teams bash for up to 8 players.

In order to play this may, unzip it into your SIERRA\Homeworld\Multiplayer folder. It should have sevenfolders named Carbon2 - Carbon8 plus this text file. If you have properly placed the folders, Homeworld will automatically recognize this map on startup when you select Multiplayer maps.
