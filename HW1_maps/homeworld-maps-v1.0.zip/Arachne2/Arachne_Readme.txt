Homeworld Custom Map

====================
Creator: Dylov
E-Mail Address:  dy.lov@techemail.com

Map Name:  Arachne
File Name:  Arachne.zip
Version:  1.2 (18 March 2000)
Created With:  Excel97 and TextPad v.4.1.02
====================

Background Storyline and/or Comments:

In Greek Mythology, a Lydian girl who was so skilful a weaver that she challenged the goddess Athena to a contest. Athena tore Arachne's beautiful tapestries to pieces and Arachne hanged herself. She was transformed into a spider, and her weaving became a cobweb.

Increasing Resources will draw players to the deadly centre of this huge web... 

*************

This map has been designed for a FFA bash for up to 8 players.

In order to play this may, unzip it into your SIERRA\Homeworld\Multiplayer folder. It should have sevenfolders named Arachne2 - Arachne8 plus this text file. If you have properly placed the folders, Homeworld will automatically recognize this map on startup when you select Multiplayer maps.
