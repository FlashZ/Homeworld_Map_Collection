Please note that this map is currently in BETA, and is not ready to distribute yet. If you can help with any feed back please do so. You can reach me @   gandolph@ftc-i.net
Please delete this map after playing as I do not want different versions floating around.
Thanks,
Division.

July 21,2000