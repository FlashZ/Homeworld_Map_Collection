Homeworld Custom Map

====================
Creator: Dylov
E-Mail Address:  dy.lov@techemail.com

Map Name:   Giant Arachne
File Name:  BigArachne.zip
Version:  Arachne v2.0 (18 March 2000)
Created With:  Excel97 and TextPad v.4.1.02
====================

Background Storyline and/or Comments:

In Greek Mythology, a Lydian girl who was so skilful a weaver that she challenged the goddess Athena to a contest. Athena tore Arachne's beautiful tapestries to pieces and Arachne hanged herself. She was transformed into a spider, and her weaving became a cobweb.

Increasing Resources will draw players to the deadly centre of this huge web... 

*************

In response to the comments about the extended strands that were left in the original version and comments given over WON, here is Arachne in its full glory! This map is about twice the size of Arachne v1.0 taken up with the extended web pattern, on my CPU its just too slow and thus I can only really recommend this for the high end CPU and cable connection online games (al� TAKERS Genesis 240D). 

Other changes; Player positions have been modified to begin further from the centre, resources have been added to 3 extra 'rings', and a resource controller has been added to the starting fleet.

This map has been designed for a FFA bash for up to 8 players.

In order to play this may, unzip it into your SIERRA\Homeworld\Multiplayer folder. It should have sevenfolders named BigArachne2 - BigArachne8 plus this text file. If you have properly placed the folders, Homeworld will automatically recognize this map on startup when you select Multiplayer maps.
